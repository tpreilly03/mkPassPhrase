package org.tpreillysoftware.javafx;

public record Stig(String filename, String date) {
}
