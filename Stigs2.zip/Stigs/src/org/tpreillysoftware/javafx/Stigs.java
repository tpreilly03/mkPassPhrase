package org.tpreillysoftware.javafx;

import javafx.application.Application;
import javafx.concurrent.Worker;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

public class Stigs extends Application {

    private WebView webView;
    private WebEngine webEngine;
    private TextArea instructionsTextArea;
    private TabPane tabPane;
    private Tab tabDocLib;
    private BorderPane borderPane;
    private Scene scene;
    private Button processPageButton;
    private VBox vBox;
    private HBox hBox;
    private boolean pageLoaded;
    private ArrayList<String> filenames;
    private ArrayList<String> dates;
    private ArrayList<Stig> stigs;
    private DateSorterDesc dateSorterDesc;
    private int lastStigIndex;

    public Stigs() {
        this.filenames = new ArrayList<>();
        this.dates = new ArrayList<>();
        this.stigs = new ArrayList<>();
        this.dateSorterDesc = new DateSorterDesc();
        this.lastStigIndex = 0;
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {
        primaryStage.setTitle("STIGs");

        instructionsTextArea = new TextArea();
        instructionsTextArea.prefHeight(100.0);

        webView = new WebView();

        webEngine = webView.getEngine();

        webView.getEngine().load("https://public.cyber.mil/stigs/downloads/");

        // create a TabPane
        tabPane = new TabPane();

        // create Tab
        tabDocLib = new Tab("Document Library");
        tabDocLib.setContent(webView);
        tabPane.getTabs().add(tabDocLib);

        // create multiple tabs
        for (int i = 1; i < 10; i++) {

            // create Tab
            Tab tab = new Tab("Tab_" + (i + 1));

            // create a label
            Label label = new Label("This is Tab: " + (i + 1));

            // add label to the tab
            tab.setContent(label);

            // add tab
            tabPane.getTabs().add(tab);
        }

        processPageButton = new Button();
        processPageButton.setText("Process Page");
        processPageButton.setOnMousePressed(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                processPage();
            }
        });
        processPageButton.setDisable(true);

        hBox = new HBox();
        hBox.getChildren().add(processPageButton);

        vBox = new VBox();
        vBox.getChildren().add(instructionsTextArea);
        vBox.getChildren().add(hBox);

        borderPane = new BorderPane();
        borderPane.setTop(vBox);
        borderPane.setCenter(tabPane);

        scene = new Scene(borderPane);

        primaryStage.setScene(scene);
        primaryStage.show();

        pageLoaded = false;
        webEngine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if ((newState == Worker.State.SUCCEEDED) && !pageLoaded) {
                // new page has loaded, process:
                pageLoaded = true;
                processPageButton.setDisable(false);
                //processPage();
                //for ( Stig stig:stigs) {
                //    System.out.println(new StringBuilder().append("filename: ").append(stig.filename()).append(" date: ").append(stig.date()).toString());
                //}
            }
        });

    }

    private void processPage() {
        filenames.clear();
        dates.clear();
        stigs.clear();

        Document document = webEngine.getDocument();
        NodeList nodeList1 = document.getElementsByTagName("tr");
        for (int i = 1; i < nodeList1.getLength(); i++) {
            Node node1 = nodeList1.item(i);
            if (node1.getNodeType() == Node.ELEMENT_NODE) {
                // do something with the current element
                //System.out.println(node1.getNodeName() + " " + i);
                NodeList nodeList11 = node1.getChildNodes();
                for (int j = 0; j < nodeList11.getLength(); j++) {
                    Node node11 = nodeList11.item(j);
                    if (node11.getNodeType() == Node.ELEMENT_NODE) {
                        // do something with the current element
                        //System.out.println(node11.getNodeName()+ " " + j);
                        NodeList nodeList111 = node11.getChildNodes();
                        for (int k = 0; k < nodeList111.getLength(); k++) {
                            //System.out.println("k=" + k + " tp1");
                            Node node111 = nodeList111.item(k);
                            if (node111.getNodeType() == Node.ELEMENT_NODE) {
                                //System.out.println("k=" + k + " tp2");
                                // do something with the current element
                                if (("a".equalsIgnoreCase(node111.getNodeName())) || ("span".equalsIgnoreCase(node111.getNodeName()))) {
                                    //System.out.println("k=" + k + " tp3");
                                    if ("a".equalsIgnoreCase(node111.getNodeName())) {
                                        //System.out.println("k=" + k + " tp4");
                                        NamedNodeMap namedNodeMapFilename = node111.getAttributes();
                                        String[] hrefStrArray = namedNodeMapFilename.getNamedItem("href").getNodeValue().toString().split("/");
                                        String filename = new String(hrefStrArray[hrefStrArray.length - 1]);
                                        filenames.add(filename);
                                        //System.out.println(node111.getNodeName() + " " + filename);
                                    }
                                    if ("span".equalsIgnoreCase(node111.getNodeName())) {
                                        //System.out.println("k=" + k + " tp5");
                                        NamedNodeMap namedNodeMapDate = node111.getParentNode().getAttributes();
                                        //System.out.println("k=" + k + " class value=" + namedNodeMapDate.getNamedItem("class").getNodeValue().toString());
                                        if (namedNodeMapDate.getNamedItem("class").getNodeValue().toString().contains("updated_column")) {
                                            //System.out.println("k=" + k + " tp6");
                                            String dateString = new String(node111.getTextContent().strip());
                                            dates.add(dateString);
                                            //System.out.println(node111.getNodeName() + " Date: " + dateString);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        for (int i=0; i<filenames.size(); i++) {
            String dateString = dates.get(i).replaceAll(" ", "");
            Stig stig = new Stig(filenames.get(i), dateString);
            stigs.add(stig);
        }
        stigs.sort(dateSorterDesc);
        setLastStigIndex();
        for (int i=0; i<=lastStigIndex; i++) {
            System.out.println(new StringBuilder().append("filename: ").append(stigs.get(i).filename()).append(" date: ").append(stigs.get(i).date()).toString());
        }
        downloadStig(stigs.get(1).filename(), "/Users/treilly/Downloads/stigs");

    } // private void processPage() {

    private void downloadStig(String filename, String destination) {
        try (BufferedInputStream in = new BufferedInputStream(new URL("https://dl.dod.cyber.mil/wp-content/uploads/stigs/zip/" + filename).openStream());
             FileOutputStream fileOutputStream = new FileOutputStream(destination + File.separator + filename)) {
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
        } catch (IOException e) {
            // handle exception
        }
    }

    private String getFirstOfPreviousMonth() {
        LocalDate currentDate = LocalDate.now();
        System.out.println("Current date: "+currentDate);
        //Getting the current month
        int currentMonth = currentDate.getMonth().getValue();
        System.out.println("Current month: "+currentMonth);
        //getting the current year
        int currentYear = currentDate.getYear();
        System.out.println("Current year: "+currentYear);

        int prevMonth = (currentMonth == 1 ? 12 : currentMonth - 1);
        System.out.println("Previous month: "+prevMonth);
        int year = (currentMonth == 1 ? currentYear - 1 : currentYear);
        System.out.println("Year: " + year);

        return String.format("%4d", year) + String.format("%02d", prevMonth) + "01";
    }

    private void setLastStigIndex() {
        int firstOfPrevMonth = Integer.parseInt(getFirstOfPreviousMonth());

        int stigDate;
        int i;
        for (i=0; i<stigs.size(); i++) {
            stigDate = Integer.parseInt(stigs.get(i).date());
            if (stigDate < firstOfPrevMonth) {
                lastStigIndex = i-1;
                break;
            }
        }
        lastStigIndex = i-1;
    }
}
