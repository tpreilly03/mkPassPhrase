package org.tpreillysoftware.javafx;

import javafx.application.Application;
import javafx.concurrent.Worker;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

public class Stigs extends Application {

    private WebView webView;
    private WebEngine webEngine;
    private TextArea textArea;
    private TabPane tabPane;
    private Tab tabDocLib;
    private BorderPane borderPane;
    private Scene scene;
    private Button processPageButton;
    private VBox vBox;
    private boolean pageLoaded;
    private ArrayList<String> filenames;
    private ArrayList<String> dates;
    private ArrayList<Stig> stigs;
    private DateSorterDesc dateSorterDesc;

    public Stigs() {
        this.filenames = new ArrayList<>();
        this.dates = new ArrayList<>();
        this.stigs = new ArrayList<>();
        this.dateSorterDesc = new DateSorterDesc();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {
        primaryStage.setTitle("STIGs");

        textArea = new TextArea();
        textArea.prefHeight(100.0);

        webView = new WebView();

        webEngine = webView.getEngine();

        webView.getEngine().load("https://public.cyber.mil/stigs/downloads/");

        // create a TabPane
        tabPane = new TabPane();

        // create Tab
        tabDocLib = new Tab("Document Library");
        tabDocLib.setContent(webView);
        tabPane.getTabs().add(tabDocLib);

        // create multiple tabs
        for (int i = 1; i < 10; i++) {

            // create Tab
            Tab tab = new Tab("Tab_" + (i + 1));

            // create a label
            Label label = new Label("This is Tab: " + (i + 1));

            // add label to the tab
            tab.setContent(label);

            // add tab
            tabPane.getTabs().add(tab);
        }

        processPageButton = new Button();
        processPageButton.setText("Process Page");
        processPageButton.setOnMousePressed(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent me) {
                processPage();
            }
        });

        vBox = new VBox();
        vBox.getChildren().add(processPageButton);
        vBox.getChildren().add(tabPane);

        borderPane = new BorderPane();
        borderPane.setTop(textArea);
        borderPane.setCenter(vBox);

        scene = new Scene(borderPane);

        primaryStage.setScene(scene);
        primaryStage.show();

        pageLoaded = false;
        webEngine.getLoadWorker().stateProperty().addListener((obs, oldState, newState) -> {
            if ((newState == Worker.State.SUCCEEDED) && !pageLoaded) {
                // new page has loaded, process:
                pageLoaded = true;
                //processPage();
                //for ( Stig stig:stigs) {
                //    System.out.println(new StringBuilder().append("filename: ").append(stig.filename()).append(" date: ").append(stig.date()).toString());
                //}
            }
        });

    }

    private void processPage() {
        filenames.clear();
        dates.clear();
        stigs.clear();

        Document document = webEngine.getDocument();
        NodeList nodeList1 = document.getElementsByTagName("tr");
        for (int i = 1; i < nodeList1.getLength(); i++) {
            Node node1 = nodeList1.item(i);
            if (node1.getNodeType() == Node.ELEMENT_NODE) {
                // do something with the current element
                //System.out.println(node1.getNodeName() + " " + i);
                NodeList nodeList11 = node1.getChildNodes();
                for (int j = 0; j < nodeList11.getLength(); j++) {
                    Node node11 = nodeList11.item(j);
                    if (node11.getNodeType() == Node.ELEMENT_NODE) {
                        // do something with the current element
                        //System.out.println(node11.getNodeName()+ " " + j);
                        NodeList nodeList111 = node11.getChildNodes();
                        for (int k = 0; k < nodeList111.getLength(); k++) {
                            Node node111 = nodeList111.item(k);
                            if (node111.getNodeType() == Node.ELEMENT_NODE) {
                                // do something with the current element
                                if (("a".equalsIgnoreCase(node111.getNodeName())) || ("span".equalsIgnoreCase(node111.getNodeName()))) {
                                    if ("a".equalsIgnoreCase(node111.getNodeName())) {
                                        NamedNodeMap namedNodeMapFilename = node111.getAttributes();
                                        String[] hrefStrArray = namedNodeMapFilename.getNamedItem("href").getNodeValue().toString().split("/");
                                        String filename = new String(hrefStrArray[hrefStrArray.length - 1]);
                                        filenames.add(filename);
                                        //System.out.println(node111.getNodeName() + " " + filename);
                                    }
                                    if ("span".equalsIgnoreCase(node111.getNodeName())) {
                                        NamedNodeMap namedNodeMapDate = node111.getParentNode().getAttributes();
                                        if ("updated_column".equalsIgnoreCase(namedNodeMapDate.getNamedItem("class").getNodeValue().toString())) {
                                            String dateString = new String(node111.getTextContent().strip());
                                            dates.add(dateString);
                                            //System.out.println(node111.getNodeName() + " Year: " + dateStrArray[0] + " Month: " + dateStrArray[1] + " Day: " + dateStrArray[2]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        for (int i=0; i<filenames.size(); i++) {
            String dateString = dates.get(i).replaceAll(" ", "");
            Stig stig = new Stig(filenames.get(i), dateString);
            stigs.add(stig);
        }
        stigs.sort(dateSorterDesc);
        for ( Stig stig:stigs) {
            System.out.println(new StringBuilder().append("filename: ").append(stig.filename()).append(" date: ").append(stig.date()).toString());
        }
    } // private void processPage() {
}
