package org.tpreillysoftware.javafx;

import java.util.Comparator;

public class DateSorterDesc implements Comparator<Stig>
{
    @Override
    public int compare(Stig obj1, Stig obj2) {
        int obj1int = Integer.parseInt(obj1.date());
        int obj2int = Integer.parseInt(obj2.date());

        return Integer.compare(obj2int, obj1int);
    }
}
